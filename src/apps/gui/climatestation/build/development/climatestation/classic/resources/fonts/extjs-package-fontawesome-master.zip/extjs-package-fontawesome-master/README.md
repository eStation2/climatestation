# extjs-package-fontawesome
Font Awesome v5 package of ExtJS

## Useage
Replace your
`<project_home>/ext(framework_dir)/packages/font-awesome/`
with
`<this repository>/font-awesome/`  
  
then
run `sencha app refresh`
  

## How to do it yourself
https://qiita.com/yamayamayamaji/items/4b5fa6e5809cd17fced8
