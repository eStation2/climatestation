# font-awesome

This package bundles Font Awesome for use by Sencha Cmd applications and packages.
To use this package, simply require it from `app.json`:

    "requires": [
        "font-awesome"
    ]

See the Font Awesome [web page](http://fortawesome.github.io/Font-Awesome/) for
more details.
